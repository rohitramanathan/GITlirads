    return angular.module('ngTable');
}));