var app = angular.module('angularjs-starter', []);

app.controller('MainCtrl', function($scope) {
  $scope.name = 'World';
});

app.config(function($routeProvider,$locationProvider){
   $routeProvider
    .when('/a',{'templateUrl' : 'a.html'})
    .when('/b',{'templateUrl' : 'b.html'})
    .otherwise({redirectTo : '/a'})
});